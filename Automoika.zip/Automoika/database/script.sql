-- =====================================================
-- АИС "Автомойка: система электронной очереди"
-- Полный скрипт создания БД и наполнения данными
-- PostgreSQL + Spring Boot + Security
-- Период данных: 10 июня – 30 июня 2026 г.
-- =====================================================
-- CREATE DATABASE carwash_ais;
-- Удаляем таблицы в правильном порядке
DROP TABLE IF EXISTS queue_assignments CASCADE;
DROP TABLE IF EXISTS queue_entries CASCADE;
DROP TABLE IF EXISTS time_slots CASCADE;
DROP TABLE IF EXISTS wash_services CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- =====================================================
-- 1. Пользователи (ADMIN, OPERATOR, CLIENT)
-- =====================================================
CREATE TABLE users (
    id         SERIAL PRIMARY KEY,
    username   VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    full_name  VARCHAR(200) NOT NULL,
    phone      VARCHAR(20),
    role       VARCHAR(20) NOT NULL,
    is_worker  BOOLEAN DEFAULT FALSE,
    enabled    BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- 2. Услуги автомойки
-- =====================================================
CREATE TABLE wash_services (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL UNIQUE,
    description     TEXT,
    duration_minutes INT NOT NULL,
    price           DECIMAL(10,2) NOT NULL,
    sort_order      INT DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- 3. Временные слоты (справочник)
-- =====================================================
CREATE TABLE time_slots (
    id              SERIAL PRIMARY KEY,
    slot_time       TIME NOT NULL UNIQUE,
    is_active       BOOLEAN DEFAULT TRUE
);

-- =====================================================
-- 4. Электронная очередь
-- =====================================================
CREATE TABLE queue_entries (
    id              SERIAL PRIMARY KEY,
    user_id         INT NOT NULL REFERENCES users(id),
    license_plate   VARCHAR(20) NOT NULL,
    car_type        VARCHAR(30),
    service_id      INT NOT NULL REFERENCES wash_services(id),
    slot_time       TIME NOT NULL,
    entry_date      DATE NOT NULL,
    queue_number    INT,
    status          VARCHAR(20) DEFAULT 'PENDING',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes           TEXT,
    created_by      INT REFERENCES users(id),
    assigned_worker_id INT REFERENCES users(id)
);
CREATE INDEX idx_queue_date ON queue_entries(entry_date);
CREATE INDEX idx_queue_status ON queue_entries(status);

-- =====================================================
-- 5. Назначение исполнителей
-- =====================================================
CREATE TABLE queue_assignments (
    id              SERIAL PRIMARY KEY,
    queue_entry_id  INT NOT NULL REFERENCES queue_entries(id) ON DELETE CASCADE,
    worker_id       INT NOT NULL REFERENCES users(id),
    assigned_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status          VARCHAR(20) DEFAULT 'ASSIGNED'
);
CREATE INDEX idx_assignments_entry ON queue_assignments(queue_entry_id);

-- =====================================================
-- Триггер для автоматического расчёта queue_number
-- =====================================================
CREATE OR REPLACE FUNCTION calculate_queue_number()
RETURNS TRIGGER AS $$
BEGIN
    SELECT COALESCE(MAX(queue_number), 0) + 1 INTO NEW.queue_number
    FROM queue_entries
    WHERE entry_date = NEW.entry_date;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_calculate_queue_number ON queue_entries;
CREATE TRIGGER trigger_calculate_queue_number
BEFORE INSERT ON queue_entries
FOR EACH ROW
EXECUTE FUNCTION calculate_queue_number();

-- =====================================================
-- ТЕСТОВЫЕ ДАННЫЕ (период: 10.06.2026 – 30.06.2026)
-- =====================================================

-- Пользователи (пароль для всех: password123)
INSERT INTO users (username, password, email, full_name, phone, role, is_worker, enabled) VALUES
('admin', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'admin@wash.ru', 'Гиниятуллина Аделина Администратор', '+7-999-111-22-33', 'ADMIN', false, true),
('operator1', '$2a$12$Hon8pPYzIGh9riMNru4yPe5DkDFVfYREY8lTJAXY4u9HUYeKeo0m.', 'operator@wash.ru', 'Сидорова Ольга Оператор', '+7-999-333-44-55', 'OPERATOR', false, true),
('worker1', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'worker1@wash.ru', 'Михайлов Михаил Мойщик', '+7-999-777-88-99', 'OPERATOR', true, true),
('worker2', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'worker2@wash.ru', 'Кузнецов Дмитрий Мойщик', '+7-999-888-99-00', 'OPERATOR', true, true),
('client1', '$2a$12$0ejU0jQN8umQFztyr8k9guCicS6vJJ3yvMZU.sMWSHow3BDw7/wZC', 'ivanov@mail.ru', 'Иванов Иван Иванович', '+7-999-444-55-66', 'CLIENT', false, true),
('client2', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'petrov@mail.ru', 'Петров Петр Петрович', '+7-999-555-66-77', 'CLIENT', false, true),
('client3', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'sidorova@mail.ru', 'Сидорова Анна Сергеевна', '+7-999-666-77-88', 'CLIENT', false, true),
('client4', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'smirnov@mail.ru', 'Смирнов Алексей Дмитриевич', '+7-999-777-88-99', 'CLIENT', false, true),
('client5', '$2a$12$qWNfVautpiXa0XBZDR.M.OIebcluxz1IFQWaVnQRsnz5odhSYwidi', 'kozlov@mail.ru', 'Козлов Денис Андреевич', '+7-999-888-99-00', 'CLIENT', false, true);

-- Услуги
INSERT INTO wash_services (name, description, duration_minutes, price, sort_order) VALUES
('Экспресс-мойка', 'Быстрая наружная мойка', 15, 300.00, 1),
('Стандартная мойка', 'Наружная мойка + сушка', 25, 500.00, 2),
('Комплексная мойка', 'Мойка кузова + салона', 45, 1200.00, 3),
('Химчистка салона', 'Глубокая чистка салона', 90, 2500.00, 4),
('Полировка кузова', 'Восстановление блеска краски', 60, 2000.00, 5),
('Антидождь', 'Нанесение гидрофобного покрытия', 20, 800.00, 6);

-- Временные слоты (с 8:00 до 20:00)
INSERT INTO time_slots (slot_time) VALUES
('08:00'), ('08:30'), ('09:00'), ('09:30'), ('10:00'), ('10:30'),
('11:00'), ('11:30'), ('12:00'), ('12:30'), ('13:00'), ('13:30'),
('14:00'), ('14:30'), ('15:00'), ('15:30'), ('16:00'), ('16:30'),
('17:00'), ('17:30'), ('18:00'), ('18:30'), ('19:00'), ('19:30');

-- =====================================================
-- ЗАПИСИ В ОЧЕРЕДЬ (10-30 июня 2026)
-- =====================================================

-- Записи на 10 июня 2026
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by, assigned_worker_id) VALUES
(5, 'А777АА77', 'Седан', 1, '09:00', '2026-06-10', 'COMPLETED', 2, 3),
(5, 'А777АА77', 'Седан', 2, '10:00', '2026-06-10', 'COMPLETED', 2, 4),
(6, 'В888ВВ77', 'Кроссовер', 3, '11:00', '2026-06-10', 'COMPLETED', 2, 3),
(7, 'С999СС77', 'Внедорожник', 1, '12:00', '2026-06-10', 'COMPLETED', 2, 4),
(8, 'К777КК77', 'Седан', 2, '14:00', '2026-06-10', 'COMPLETED', 2, 3),
(9, 'М111ММ77', 'Кроссовер', 4, '15:00', '2026-06-10', 'COMPLETED', 2, 4);

-- Записи на 15 июня 2026
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by, assigned_worker_id) VALUES
(5, 'А777АА77', 'Седан', 1, '09:30', '2026-06-15', 'COMPLETED', 2, 3),
(6, 'В888ВВ77', 'Кроссовер', 2, '10:30', '2026-06-15', 'COMPLETED', 2, 4),
(7, 'С999СС77', 'Внедорожник', 3, '11:30', '2026-06-15', 'COMPLETED', 2, 3),
(8, 'К777КК77', 'Седан', 5, '13:00', '2026-06-15', 'COMPLETED', 2, 4),
(9, 'М111ММ77', 'Кроссовер', 1, '14:30', '2026-06-15', 'COMPLETED', 2, 3),
(5, 'А777АА77', 'Седан', 6, '16:00', '2026-06-15', 'COMPLETED', 2, 4);

-- Записи на 20 июня 2026
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by, assigned_worker_id) VALUES
(6, 'В888ВВ77', 'Кроссовер', 1, '09:00', '2026-06-20', 'COMPLETED', 2, 3),
(7, 'С999СС77', 'Внедорожник', 2, '10:00', '2026-06-20', 'COMPLETED', 2, 4),
(8, 'К777КК77', 'Седан', 3, '11:00', '2026-06-20', 'COMPLETED', 2, 3),
(9, 'М111ММ77', 'Кроссовер', 4, '12:00', '2026-06-20', 'COMPLETED', 2, 4),
(5, 'А777АА77', 'Седан', 1, '13:30', '2026-06-20', 'COMPLETED', 2, 3),
(6, 'В888ВВ77', 'Кроссовер', 5, '15:00', '2026-06-20', 'COMPLETED', 2, 4);

-- Записи на 25 июня 2026
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by, assigned_worker_id) VALUES
(7, 'С999СС77', 'Внедорожник', 1, '09:00', '2026-06-25', 'COMPLETED', 2, 3),
(8, 'К777КК77', 'Седан', 2, '10:00', '2026-06-25', 'COMPLETED', 2, 4),
(9, 'М111ММ77', 'Кроссовер', 3, '11:00', '2026-06-25', 'COMPLETED', 2, 3),
(5, 'А777АА77', 'Седан', 6, '12:00', '2026-06-25', 'COMPLETED', 2, 4),
(6, 'В888ВВ77', 'Кроссовер', 1, '13:00', '2026-06-25', 'COMPLETED', 2, 3),
(7, 'С999СС77', 'Внедорожник', 4, '14:30', '2026-06-25', 'COMPLETED', 2, 4);

-- Активные записи на сегодня (21 июня) и будущие даты
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by) VALUES
(5, 'А777АА77', 'Седан', 1, '09:00', CURRENT_DATE, 'PENDING', 2),
(5, 'А777АА77', 'Седан', 2, '10:00', CURRENT_DATE, 'ASSIGNED', 2),
(6, 'В888ВВ77', 'Кроссовер', 3, '11:00', CURRENT_DATE, 'IN_PROGRESS', 2),
(7, 'С999СС77', 'Внедорожник', 1, '12:00', CURRENT_DATE, 'ASSIGNED', 2),
(8, 'К777КК77', 'Седан', 2, '13:30', CURRENT_DATE, 'PENDING', 2),
(9, 'М111ММ77', 'Кроссовер', 4, '15:00', CURRENT_DATE, 'PENDING', 2);

-- Записи на 22 июня
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by) VALUES
(5, 'А777АА77', 'Седан', 1, '09:00', '2026-06-22', 'PENDING', 2),
(6, 'В888ВВ77', 'Кроссовер', 2, '10:30', '2026-06-22', 'PENDING', 2),
(7, 'С999СС77', 'Внедорожник', 3, '11:30', '2026-06-22', 'PENDING', 2),
(8, 'К777КК77', 'Седан', 1, '13:00', '2026-06-22', 'PENDING', 2);

-- Записи на 23 июня
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by) VALUES
(9, 'М111ММ77', 'Кроссовер', 2, '09:30', '2026-06-23', 'PENDING', 2),
(5, 'А777АА77', 'Седан', 3, '10:30', '2026-06-23', 'PENDING', 2),
(6, 'В888ВВ77', 'Кроссовер', 1, '11:30', '2026-06-23', 'PENDING', 2),
(7, 'С999СС77', 'Внедорожник', 5, '14:00', '2026-06-23', 'PENDING', 2);

-- Записи на 30 июня
INSERT INTO queue_entries (user_id, license_plate, car_type, service_id, slot_time, entry_date, status, created_by) VALUES
(5, 'А777АА77', 'Седан', 1, '09:00', '2026-06-30', 'PENDING', 2),
(6, 'В888ВВ77', 'Кроссовер', 2, '10:00', '2026-06-30', 'PENDING', 2),
(7, 'С999СС77', 'Внедорожник', 3, '11:00', '2026-06-30', 'PENDING', 2),
(8, 'К777КК77', 'Седан', 4, '12:00', '2026-06-30', 'PENDING', 2),
(9, 'М111ММ77', 'Кроссовер', 1, '13:30', '2026-06-30', 'PENDING', 2);

-- =====================================================
-- НАЗНАЧЕНИЯ ИСПОЛНИТЕЛЕЙ (используем подзапросы для ID)
-- =====================================================

-- Завершённые (10 июня)
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '09:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '10:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '11:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '12:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '14:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-10' AND slot_time = '15:00' LIMIT 1;

-- Завершённые (15 июня)
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '09:30' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '10:30' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '11:30' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '13:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '14:30' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-15' AND slot_time = '16:00' LIMIT 1;

-- Завершённые (20 июня)
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '09:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '10:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '11:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '12:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '13:30' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-20' AND slot_time = '15:00' LIMIT 1;

-- Завершённые (25 июня)
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '09:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '10:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '11:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '12:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '13:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'COMPLETED' FROM queue_entries WHERE entry_date = '2026-06-25' AND slot_time = '14:30' LIMIT 1;

-- Активные на сегодня
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'PENDING' FROM queue_entries WHERE entry_date = CURRENT_DATE AND slot_time = '09:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'ASSIGNED' FROM queue_entries WHERE entry_date = CURRENT_DATE AND slot_time = '10:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 3, 'STARTED' FROM queue_entries WHERE entry_date = CURRENT_DATE AND slot_time = '11:00' LIMIT 1;
INSERT INTO queue_assignments (queue_entry_id, worker_id, status)
SELECT id, 4, 'ASSIGNED' FROM queue_entries WHERE entry_date = CURRENT_DATE AND slot_time = '12:00' LIMIT 1;

-- =====================================================
-- ПРОВЕРКА
-- =====================================================
DO $$
BEGIN
    RAISE NOTICE '=== ИНИЦИАЛИЗАЦИЯ ЗАВЕРШЕНА ===';
    RAISE NOTICE 'Пользователей: %', (SELECT COUNT(*) FROM users);
    RAISE NOTICE 'Услуг: %', (SELECT COUNT(*) FROM wash_services);
    RAISE NOTICE 'Временных слотов: %', (SELECT COUNT(*) FROM time_slots);
    RAISE NOTICE 'Записей в очереди: %', (SELECT COUNT(*) FROM queue_entries);
    RAISE NOTICE 'Назначений: %', (SELECT COUNT(*) FROM queue_assignments);
END $$;