package com.carwash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarwashManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(CarwashManagerApplication.class, args);
        System.out.println("""
        \n=========================================
        🧼 АИС "Автомойка: система электронной очереди" запущена!
        Доступно по адресу: http://localhost:8080
        📋 Данные для входа:
        - admin / password123 (Администратор)
        - operator1 / password123 (Оператор)
        - client1 / password123 (Клиент)
        =========================================
        """);
    }
}