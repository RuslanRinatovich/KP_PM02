package com.carwash.config;

import com.carwash.service.CustomUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public AuthenticationFailureHandler authenticationFailureHandler() {
        return new CustomAuthenticationFailureHandler();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // Настройка UserDetailsService
                .userDetailsService(userDetailsService)

                // Настройка авторизации запросов
                .authorizeHttpRequests(auth -> auth
                        // Публичные страницы (доступны всем)
                        .requestMatchers("/", "/login", "/register", "/css/**", "/js/**", "/webjars/**", "/images/**").permitAll()

                        // Администратор
                        .requestMatchers("/admin/**").hasRole("ADMIN")

                        // Оператор (и мойщики – тоже OPERATOR)
                        .requestMatchers("/operator/**").hasAnyRole("OPERATOR")

                        // Клиент
                        .requestMatchers("/client/**").hasRole("CLIENT")

                        // Редирект на дашборд
                        .requestMatchers("/dashboard").authenticated()

                        // Все остальные запросы требуют аутентификации
                        .anyRequest().authenticated()
                )

                // Настройка формы логина
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/dashboard", true)
                        .failureHandler(authenticationFailureHandler())  // ← добавляем обработчик ошибок
                        .permitAll()
                )

                // Настройка выхода из системы
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login?logout")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                        .permitAll()
                )

                // Настройка сессий
                .sessionManagement(session -> session
                        .maximumSessions(1)
                        .expiredUrl("/login?expired")
                )

                // Отключаем CSRF для упрощения
                .csrf(csrf -> csrf.disable());

        return http.build();
    }
}