package com.carwash.controller;

import com.carwash.entity.User;
import com.carwash.dto.RegistrationDto;
import com.carwash.repository.QueueEntryRepository;
import com.carwash.repository.UserRepository;
import com.carwash.repository.WashServiceRepository;
import com.carwash.service.CustomUserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final CustomUserDetailsService userDetailsService;
    private final UserRepository userRepository;
    private final WashServiceRepository washServiceRepository;
    private final QueueEntryRepository queueEntryRepository;

    private final PasswordEncoder passwordEncoder;
    @GetMapping("/")
    public String redirectToLogin() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String redirectToDashboard() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (GrantedAuthority authority : auth.getAuthorities()) {
            String role = authority.getAuthority();
            if (role.equals("ROLE_ADMIN")) {
                return "redirect:/admin/dashboard";
            } else if (role.equals("ROLE_OPERATOR")) {
                return "redirect:/operator/dashboard";
            } else if (role.equals("ROLE_CLIENT")) {
                return "redirect:/client/dashboard";
            }
        }
        return "redirect:/login";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userDetailsService.getUserByUsername(auth.getName());

        model.addAttribute("pageTitle", "Панель администратора");
        model.addAttribute("userRole", "Администратор");
        model.addAttribute("username", user.getUsername());
        model.addAttribute("fullName", user.getFullName());

        // Статистика для админа
        model.addAttribute("totalUsers", userRepository.count());
        model.addAttribute("totalServices", washServiceRepository.count());
        model.addAttribute("todayQueueCount", queueEntryRepository.countByEntryDate(LocalDate.now()));

        return "dashboard/admin";
    }

    @GetMapping("/operator/dashboard")
    public String operatorDashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userDetailsService.getUserByUsername(auth.getName());

        model.addAttribute("pageTitle", "Панель оператора");
        model.addAttribute("userRole", user.isWorker() ? "Мойщик" : "Оператор");
        model.addAttribute("username", user.getUsername());
        model.addAttribute("fullName", user.getFullName());
        model.addAttribute("isWorker", user.isWorker());

        // Статистика для оператора
        var todayQueue = queueEntryRepository.findByEntryDateOrderByQueueNumberAsc(LocalDate.now());
        model.addAttribute("todayQueueCount", todayQueue.size());
        model.addAttribute("inProgressCount", todayQueue.stream().filter(e -> "IN_PROGRESS".equals(e.getStatus())).count());
        model.addAttribute("completedTodayCount", todayQueue.stream().filter(e -> "COMPLETED".equals(e.getStatus())).count());
        model.addAttribute("todayQueue", todayQueue);

        return "dashboard/operator";
    }

    @GetMapping("/client/dashboard")
    public String clientDashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userDetailsService.getUserByUsername(auth.getName());

        model.addAttribute("pageTitle", "Панель клиента");
        model.addAttribute("userRole", "Клиент");
        model.addAttribute("username", user.getUsername());
        model.addAttribute("fullName", user.getFullName());

        // Активные записи клиента
        var activeBookings = queueEntryRepository.findActiveByUserId(user.getId());
        model.addAttribute("activeBookingsCount", activeBookings.size());
        model.addAttribute("myActiveBookings", activeBookings);

        // Завершённые мойки
        var allBookings = queueEntryRepository.findByUserId(user.getId());
        long completedCount = allBookings.stream()
                .filter(e -> "COMPLETED".equals(e.getStatus()))
                .count();
        model.addAttribute("completedBookingsCount", completedCount);

        // Количество автомобилей (если нужны – можно убрать или добавить позже)
        model.addAttribute("myCarsCount", 0); // временно

        return "dashboard/client";
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("registrationDto", new RegistrationDto());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute RegistrationDto dto, RedirectAttributes ra) {
        // Проверка на существование логина
        if (userRepository.existsByUsername(dto.getUsername())) {
            ra.addFlashAttribute("error", "Пользователь с таким логином уже существует");
            return "redirect:/register";
        }

        // Проверка на существование email
        if (userRepository.existsByEmail(dto.getEmail())) {
            ra.addFlashAttribute("error", "Пользователь с таким email уже существует");
            return "redirect:/register";
        }

        // Проверка совпадения паролей
        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            ra.addFlashAttribute("error", "Пароли не совпадают");
            return "redirect:/register";
        }

        // Создание нового пользователя
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setEmail(dto.getEmail());
        user.setFullName(dto.getFullName());
        user.setPhone(dto.getPhone());
        user.setRole("CLIENT");
        user.setWorker(false);
        user.setEnabled(true);

        userRepository.save(user);

        ra.addFlashAttribute("success", "Регистрация прошла успешно! Войдите в систему.");
        return "redirect:/login";
    }
}