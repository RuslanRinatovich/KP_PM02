package com.carwash.controller.admin;

import com.carwash.dto.QueueEntryDto;
import com.carwash.repository.UserRepository;
import com.carwash.repository.WashServiceRepository;
import com.carwash.service.QueueService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Controller
@RequestMapping("/admin/queue")
@RequiredArgsConstructor
public class AdminQueueController {

    private final QueueService queueService;
    private final UserRepository userRepository;
    private final WashServiceRepository washServiceRepository;

    @GetMapping
    public String viewQueue(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                            Model model) {
        if (date == null) {
            date = LocalDate.now();
        }

        model.addAttribute("selectedDate", date);
        model.addAttribute("queue", queueService.getQueueByDate(date));
        model.addAttribute("workers", userRepository.findAllWorkers());
        model.addAttribute("clients", userRepository.findAllClients());
        model.addAttribute("services", washServiceRepository.findByIsActiveTrueOrderBySortOrderAsc());
        model.addAttribute("freeSlots", queueService.getFreeSlots(date));
        model.addAttribute("activeMenu", "queue");
        return "admin/queue";
    }

    @PostMapping("/create")
    public String createQueueEntry(@ModelAttribute QueueEntryDto dto,
                                   @RequestParam(required = false) String selectedDate,
                                   RedirectAttributes ra) {
        try {
            LocalDate entryDate;
            if (selectedDate != null && !selectedDate.isBlank()) {
                entryDate = LocalDate.parse(selectedDate);
            } else {
                entryDate = LocalDate.now();
            }
            dto.setEntryDate(entryDate);
            queueService.createQueueEntry(dto);
            ra.addFlashAttribute("success", "Запись в очередь добавлена");
            return "redirect:/admin/queue?date=" + entryDate.format(DateTimeFormatter.ISO_DATE);
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/admin/queue?date=" + (selectedDate != null ? selectedDate : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
        }
    }

    @PostMapping("/assign/{id}")
    public String assignWorker(@PathVariable Integer id,
                               @RequestParam Integer workerId,
                               @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                               RedirectAttributes ra) {
        try {
            queueService.assignWorker(id, workerId);
            ra.addFlashAttribute("success", "Исполнитель назначен");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }

    @PostMapping("/start/{id}")
    public String startWork(@PathVariable Integer id,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                            RedirectAttributes ra) {
        try {
            queueService.startWork(id);
            ra.addFlashAttribute("success", "Мойка начата");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }

    @PostMapping("/revert/{id}")
    public String revertWork(@PathVariable Integer id,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                             RedirectAttributes ra) {
        try {
            queueService.revertWork(id);
            ra.addFlashAttribute("success", "Статус возвращён на 'Назначен'");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }

    @PostMapping("/complete/{id}")
    public String completeWork(@PathVariable Integer id,
                               @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                               RedirectAttributes ra) {
        try {
            queueService.completeWork(id);
            ra.addFlashAttribute("success", "Мойка завершена");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }

    @GetMapping("/cancel/{id}")
    public String cancelQueueEntry(@PathVariable Integer id,
                                   @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                   RedirectAttributes ra) {
        try {
            queueService.cancelQueueEntry(id);
            ra.addFlashAttribute("success", "Запись отменена");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }

    @PostMapping("/unassign/{id}")
    public String unassignWorker(@PathVariable Integer id,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                 RedirectAttributes ra) {
        try {
            queueService.unassignWorker(id);
            ra.addFlashAttribute("success", "Назначение снято");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/queue?date=" + (date != null ? date.format(DateTimeFormatter.ISO_DATE) : LocalDate.now().format(DateTimeFormatter.ISO_DATE));
    }
}