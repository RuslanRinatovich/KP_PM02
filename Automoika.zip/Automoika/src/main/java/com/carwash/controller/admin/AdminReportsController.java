package com.carwash.controller.admin;

import com.carwash.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@Controller
@RequestMapping("/admin/reports")
@RequiredArgsConstructor
public class AdminReportsController {

    private final ReportService reportService;

    @GetMapping
    public String index(Model model) {
        model.addAttribute("activeMenu", "reports");
        return "admin/reports/index";
    }

    // Excel: Отчёт по записям
    @GetMapping("/queue/excel")
    public ResponseEntity<byte[]> queueExcel(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws Exception {
        byte[] data = reportService.generateQueueExcel(startDate, endDate);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=queue.xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(data);
    }

    // PDF: Отчёт по записям
    @GetMapping("/queue/pdf")
    public ResponseEntity<byte[]> queuePdf(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws Exception {
        byte[] data = reportService.generateQueuePdf(startDate, endDate);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=queue.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(data);
    }

    // Excel: Финансовый отчёт
    @GetMapping("/financial/excel")
    public ResponseEntity<byte[]> financialExcel(@RequestParam int year, @RequestParam int month) throws Exception {
        byte[] data = reportService.generateFinancialExcel(year, month);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=financial_" + year + "_" + month + ".xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(data);
    }

    // PDF: Загрузка по типам кузова
    @GetMapping("/utilization/pdf")
    public ResponseEntity<byte[]> utilizationPdf(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws Exception {
        byte[] data = reportService.generateUtilizationPdf(startDate, endDate);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=utilization.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(data);
    }

    // Excel: Статистика по услугам
    @GetMapping("/services/excel")
    public ResponseEntity<byte[]> servicesExcel(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws Exception {
        byte[] data = reportService.generateServiceStatsExcel(startDate, endDate);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=services.xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(data);
    }
}