package com.carwash.controller.admin;

import com.carwash.dto.WashServiceDto;
import com.carwash.service.WashServiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/services")
@RequiredArgsConstructor
public class AdminServiceController {

    private final WashServiceService washServiceService;

    @GetMapping
    public String listServices(@RequestParam(required = false) String search, Model model) {
        model.addAttribute("services", washServiceService.searchServices(search));
        model.addAttribute("search", search);
        model.addAttribute("activeMenu", "services");
        return "admin/services/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("serviceDto", new WashServiceDto());
        model.addAttribute("activeMenu", "services");
        return "admin/services/form";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        WashServiceDto serviceDto = washServiceService.getServiceById(id);
        model.addAttribute("serviceDto", serviceDto);
        model.addAttribute("activeMenu", "services");
        return "admin/services/form";
    }

    @PostMapping("/save")
    public String saveService(@ModelAttribute WashServiceDto serviceDto, RedirectAttributes ra) {
        try {
            washServiceService.saveService(serviceDto);
            ra.addFlashAttribute("success", serviceDto.getId() == null ? "Услуга добавлена" : "Услуга обновлена");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/services";
    }

    @GetMapping("/delete/{id}")
    public String deleteService(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            washServiceService.deleteService(id);
            ra.addFlashAttribute("success", "Услуга удалена");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/services";
    }
}