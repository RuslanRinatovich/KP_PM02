package com.carwash.controller.admin;

import com.carwash.dto.UserDto;
import com.carwash.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/admin/users")
@RequiredArgsConstructor
public class AdminUserController {

    private final UserService userService;
    private static final List<String> ROLE_OPTIONS = Arrays.asList("ADMIN", "OPERATOR", "CLIENT");

    @GetMapping
    public String listUsers(@RequestParam(required = false) String search, Model model) {
        model.addAttribute("users", userService.searchUsers(search));
        model.addAttribute("search", search);
        model.addAttribute("activeMenu", "users");
        return "admin/users/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("userDto", new UserDto());
        model.addAttribute("roleOptions", ROLE_OPTIONS);
        model.addAttribute("activeMenu", "users");
        return "admin/users/form";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        UserDto userDto = userService.getUserById(id);
        model.addAttribute("userDto", userDto);
        model.addAttribute("roleOptions", ROLE_OPTIONS);
        model.addAttribute("activeMenu", "users");
        return "admin/users/form";
    }

    @PostMapping("/save")
    public String saveUser(@ModelAttribute UserDto userDto, RedirectAttributes ra) {
        try {
            userService.saveUser(userDto);
            ra.addFlashAttribute("success", userDto.getId() == null ? "Пользователь создан" : "Пользователь обновлён");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            userService.deleteUser(id);
            ra.addFlashAttribute("success", "Пользователь удалён");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/users";
    }
}