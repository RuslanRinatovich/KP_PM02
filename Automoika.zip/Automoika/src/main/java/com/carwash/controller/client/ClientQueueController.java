package com.carwash.controller.client;

import com.carwash.dto.QueueEntryDto;
import com.carwash.entity.QueueEntry;
import com.carwash.entity.User;
import com.carwash.repository.UserRepository;
import com.carwash.repository.WashServiceRepository;
import com.carwash.repository.QueueEntryRepository;
import com.carwash.service.QueueService;
import com.carwash.service.CustomUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/client")
@RequiredArgsConstructor
public class ClientQueueController {

    private final QueueService queueService;
    private final QueueEntryRepository queueEntryRepository;
    private final UserRepository userRepository;
    private final WashServiceRepository washServiceRepository;
    private final CustomUserDetailsService userDetailsService;

    // Страница записи на мойку
    @GetMapping("/queue/create")
    public String showCreateForm(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = userDetailsService.getUserByUsername(auth.getName());

        model.addAttribute("queueEntryDto", new QueueEntryDto());
        model.addAttribute("services", washServiceRepository.findByIsActiveTrueOrderBySortOrderAsc());
        model.addAttribute("freeSlots", getFreeSlots(LocalDate.now()));
        model.addAttribute("activeMenu", "queue");
        return "client/queue-form";
    }

    // Создание записи
    @PostMapping("/queue/create")
    public String createQueueEntry(@ModelAttribute QueueEntryDto dto,
                                   @RequestParam(required = false) String selectedDate,
                                   RedirectAttributes ra) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            User currentUser = userDetailsService.getUserByUsername(auth.getName());

            LocalDate entryDate;
            if (selectedDate != null && !selectedDate.isBlank()) {
                entryDate = LocalDate.parse(selectedDate);
            } else {
                entryDate = LocalDate.now();
            }

            dto.setUserId(currentUser.getId());
            dto.setEntryDate(entryDate);
            dto.setStatus("PENDING");

            queueService.createQueueEntry(dto);
            ra.addFlashAttribute("success", "Вы успешно записаны на мойку!");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/client/dashboard";
    }

    // Мои записи (история)
    @GetMapping("/my-queue")
    public String myQueue(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = userDetailsService.getUserByUsername(auth.getName());

        List<QueueEntry> myBookings = queueEntryRepository.findByUserIdOrderByEntryDateAsc(currentUser.getId());
        model.addAttribute("bookings", myBookings);
        model.addAttribute("activeMenu", "my-queue");
        return "client/my-queue";
    }

    // Отмена записи
    @GetMapping("/queue/cancel/{id}")
    public String cancelQueueEntry(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            queueService.cancelQueueEntry(id);
            ra.addFlashAttribute("success", "Запись отменена");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/client/my-queue";
    }

    // Получить свободные слоты
    private List<LocalTime> getFreeSlots(LocalDate date) {
        List<LocalTime> allSlots = List.of(
                LocalTime.of(9, 0), LocalTime.of(9, 30),
                LocalTime.of(10, 0), LocalTime.of(10, 30),
                LocalTime.of(11, 0), LocalTime.of(11, 30),
                LocalTime.of(12, 0), LocalTime.of(12, 30),
                LocalTime.of(13, 0), LocalTime.of(13, 30),
                LocalTime.of(14, 0), LocalTime.of(14, 30),
                LocalTime.of(15, 0), LocalTime.of(15, 30),
                LocalTime.of(16, 0), LocalTime.of(16, 30),
                LocalTime.of(17, 0), LocalTime.of(17, 30)
        );

        List<QueueEntry> busyEntries = queueEntryRepository.findByEntryDateOrderByQueueNumberAsc(date);
        List<LocalTime> busySlots = busyEntries.stream()
                .filter(e -> !e.getStatus().equals("CANCELLED") && !e.getStatus().equals("COMPLETED"))
                .map(QueueEntry::getSlotTime)
                .collect(Collectors.toList());

        return allSlots.stream()
                .filter(slot -> !busySlots.contains(slot))
                .collect(Collectors.toList());
    }
}