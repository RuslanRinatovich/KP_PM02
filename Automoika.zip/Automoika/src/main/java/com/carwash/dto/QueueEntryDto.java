package com.carwash.dto;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class QueueEntryDto {
    private Integer id;
    private Integer userId;
    private String licensePlate;
    private String carType;
    private Integer serviceId;
    private LocalTime slotTime;
    private LocalDate entryDate;
    private String status;
    private String notes;
}