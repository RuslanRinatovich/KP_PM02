package com.carwash.dto;

import lombok.Data;

@Data
public class UserDto {
    private Integer id;
    private String username;
    private String fullName;
    private String email;
    private String phone;
    private String password;
    private String role;     // ADMIN, OPERATOR, CLIENT
    private boolean enabled;
    private boolean isWorker; // Только для OPERATOR (мойщик)
}