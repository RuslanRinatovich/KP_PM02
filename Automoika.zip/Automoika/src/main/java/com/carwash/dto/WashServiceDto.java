package com.carwash.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class WashServiceDto {
    private Integer id;
    private String name;
    private String description;
    private Integer durationMinutes;
    private BigDecimal price;
    private Integer sortOrder;
    private boolean isActive;
}