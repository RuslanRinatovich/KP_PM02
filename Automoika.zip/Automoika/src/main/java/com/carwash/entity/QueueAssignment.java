package com.carwash.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "queue_assignments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueueAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "queue_entry_id", nullable = false)
    private QueueEntry queueEntry;

    @ManyToOne
    @JoinColumn(name = "worker_id", nullable = false)
    private User worker;  // OPERATOR с is_worker = TRUE

    @Column(name = "assigned_at")
    private LocalDateTime assignedAt = LocalDateTime.now();

    @Column(length = 20)
    private String status = "ASSIGNED";  // ASSIGNED, STARTED, COMPLETED
}