package com.carwash.repository;

import com.carwash.entity.QueueAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface QueueAssignmentRepository extends JpaRepository<QueueAssignment, Integer> {

    // Возвращает список (если вдруг несколько назначений)
    List<QueueAssignment> findByQueueEntryId(Integer queueEntryId);

    // Возвращает первое найденное или пустое
    default Optional<QueueAssignment> findFirstByQueueEntryId(Integer queueEntryId) {
        List<QueueAssignment> assignments = findByQueueEntryId(queueEntryId);
        return assignments.isEmpty() ? Optional.empty() : Optional.of(assignments.get(0));
    }
}