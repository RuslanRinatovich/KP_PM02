package com.carwash.repository;

import com.carwash.entity.QueueEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface QueueEntryRepository extends JpaRepository<QueueEntry, Integer> {

    // Очередь на определённую дату
    List<QueueEntry> findByEntryDateOrderByQueueNumberAsc(LocalDate date);

    // Записи пользователя по ID (все, без фильтра по статусу)
    List<QueueEntry> findByUserId(Integer userId);

    // Записи пользователя по ID с сортировкой по дате
    List<QueueEntry> findByUserIdOrderByEntryDateAsc(Integer userId);

    // Активные записи пользователя (не завершённые и не отменённые)
    @Query("SELECT q FROM QueueEntry q WHERE q.user.id = :userId AND q.status NOT IN ('COMPLETED', 'CANCELLED') ORDER BY q.entryDate ASC, q.slotTime ASC")
    List<QueueEntry> findActiveByUserId(@Param("userId") Integer userId);

    // Проверка, занят ли слот
    @Query("SELECT COUNT(q) > 0 FROM QueueEntry q WHERE q.entryDate = :date AND q.slotTime = :time AND q.status NOT IN ('CANCELLED', 'COMPLETED')")
    boolean isSlotBusy(@Param("date") LocalDate date, @Param("time") LocalTime time);

    // Количество записей на сегодня
    long countByEntryDate(LocalDate date);

    // Количество записей по статусу на сегодня
    long countByEntryDateAndStatus(LocalDate date, String status);

    // Записи мойщика (назначенные ему)
    @Query("SELECT q FROM QueueEntry q WHERE q.assignedWorker.id = :workerId AND q.status NOT IN ('COMPLETED', 'CANCELLED') ORDER BY q.entryDate ASC, q.slotTime ASC")
    List<QueueEntry> findAssignedToWorker(@Param("workerId") Integer workerId);

    // Для отчёта по записям за период
    @Query("SELECT q FROM QueueEntry q WHERE q.entryDate BETWEEN :start AND :end ORDER BY q.entryDate, q.slotTime")
    List<QueueEntry> findQueueEntriesForPeriod(@Param("start") LocalDate start, @Param("end") LocalDate end);

    // Для финансового отчёта: выручка по дням
    @Query("SELECT q.entryDate, SUM(s.price) FROM QueueEntry q JOIN q.service s WHERE q.entryDate BETWEEN :start AND :end AND q.status = 'COMPLETED' GROUP BY q.entryDate ORDER BY q.entryDate")
    List<Object[]> getDailyRevenue(@Param("start") LocalDate start, @Param("end") LocalDate end);

    // Для отчёта по загрузке по типам кузова
    @Query("SELECT q.carType, COUNT(q) FROM QueueEntry q WHERE q.entryDate BETWEEN :start AND :end AND q.status = 'COMPLETED' GROUP BY q.carType ORDER BY COUNT(q) DESC")
    List<Object[]> getCarTypeUtilization(@Param("start") LocalDate start, @Param("end") LocalDate end);

    // Для отчёта по услугам
    @Query("SELECT s.name, COUNT(q), SUM(s.price) FROM QueueEntry q JOIN q.service s WHERE q.entryDate BETWEEN :start AND :end AND q.status = 'COMPLETED' GROUP BY s.id, s.name ORDER BY COUNT(q) DESC")
    List<Object[]> getServiceStats(@Param("start") LocalDate start, @Param("end") LocalDate end);
}