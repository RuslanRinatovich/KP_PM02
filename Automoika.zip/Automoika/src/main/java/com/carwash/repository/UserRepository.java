package com.carwash.repository;

import com.carwash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {
    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.role = 'OPERATOR' AND u.isWorker = true AND u.enabled = true")
    List<User> findAllWorkers();

    @Query("SELECT u FROM User u WHERE u.role = 'OPERATOR'")
    List<User> findAllOperators();

    @Query("SELECT u FROM User u WHERE u.role = 'CLIENT' AND u.enabled = true")
    List<User> findAllClients();

    List<User> findAllByRole(String role);  // role = "OPERATOR"


    @Query("SELECT u FROM User u WHERE LOWER(u.username) LIKE LOWER(CONCAT('%', :search, '%')) OR LOWER(u.fullName) LIKE LOWER(CONCAT('%', :search, '%'))")
    List<User> searchUsers(@Param("search") String search);
}