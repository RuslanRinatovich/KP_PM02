package com.carwash.repository;

import com.carwash.entity.WashService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface WashServiceRepository extends JpaRepository<WashService, Integer> {
    List<WashService> findByIsActiveTrueOrderBySortOrderAsc();

    @Query("SELECT w FROM WashService w WHERE LOWER(w.name) LIKE LOWER(CONCAT('%', :search, '%'))")
    List<WashService> searchServices(@Param("search") String search);

    boolean existsByName(String name);
}