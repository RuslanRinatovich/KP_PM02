package com.carwash.service;

import com.carwash.dto.QueueEntryDto;
import com.carwash.entity.*;
import com.carwash.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QueueService {

    private final QueueEntryRepository queueEntryRepository;
    private final WashServiceRepository washServiceRepository;
    private final UserRepository userRepository;
    private final QueueAssignmentRepository queueAssignmentRepository;

    public List<QueueEntry> getTodayQueue() {
        return queueEntryRepository.findByEntryDateOrderByQueueNumberAsc(LocalDate.now())
                .stream()
                .sorted(Comparator.comparing(QueueEntry::getSlotTime))
                .collect(Collectors.toList());
    }

    // Получить очередь на указанную дату
    public List<QueueEntry> getQueueByDate(LocalDate date) {
        return queueEntryRepository.findByEntryDateOrderByQueueNumberAsc(date)
                .stream()
                .sorted(Comparator.comparing(QueueEntry::getSlotTime))
                .collect(Collectors.toList());
    }

    public List<QueueEntry> getClientQueue(Integer userId) {
        return queueEntryRepository.findByUserIdOrderByEntryDateAsc(userId);
    }

    public QueueEntry getQueueEntryById(Integer id) {
        return queueEntryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Запись не найдена"));
    }

    @Transactional
    public void createQueueEntry(QueueEntryDto dto) {
        if (queueEntryRepository.isSlotBusy(dto.getEntryDate(), dto.getSlotTime())) {
            throw new RuntimeException("Это время уже занято. Выберите другое время.");
        }

        User client = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Клиент не найден"));
        WashService service = washServiceRepository.findById(dto.getServiceId())
                .orElseThrow(() -> new RuntimeException("Услуга не найдена"));

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User createdBy = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        QueueEntry entry = new QueueEntry();
        entry.setUser(client);
        entry.setLicensePlate(dto.getLicensePlate());
        entry.setCarType(dto.getCarType());
        entry.setService(service);
        entry.setSlotTime(dto.getSlotTime());
        entry.setEntryDate(dto.getEntryDate());
        entry.setStatus("PENDING");
        entry.setNotes(dto.getNotes());
        entry.setCreatedBy(createdBy);

        queueEntryRepository.save(entry);
    }

    @Transactional
    public void assignWorker(Integer queueEntryId, Integer workerId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);
        User worker = userRepository.findById(workerId)
                .orElseThrow(() -> new RuntimeException("Оператор не найден"));

        if (!worker.getRole().equals("OPERATOR")) {
            throw new RuntimeException("Выбранный пользователь не является оператором");
        }

        // Удаляем старые назначения
        List<QueueAssignment> oldAssignments = queueAssignmentRepository.findByQueueEntryId(queueEntryId);
        if (!oldAssignments.isEmpty()) {
            queueAssignmentRepository.deleteAll(oldAssignments);
        }

        // Создаём новое назначение
        QueueAssignment assignment = new QueueAssignment();
        assignment.setQueueEntry(entry);
        assignment.setWorker(worker);
        assignment.setStatus("ASSIGNED");
        queueAssignmentRepository.save(assignment);

        entry.setAssignedWorker(worker);
        entry.setStatus("ASSIGNED");
        queueEntryRepository.save(entry);
    }

    @Transactional
    public void startWork(Integer queueEntryId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);
        entry.setStatus("IN_PROGRESS");
        queueEntryRepository.save(entry);
    }

    @Transactional
    public void revertWork(Integer queueEntryId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);
        if (!"IN_PROGRESS".equals(entry.getStatus())) {
            throw new RuntimeException("Вернуть статус можно только у записи со статусом 'IN_PROGRESS'");
        }
        entry.setStatus("ASSIGNED");
        queueEntryRepository.save(entry);
    }

    @Transactional
    public void completeWork(Integer queueEntryId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);
        entry.setStatus("COMPLETED");
        queueEntryRepository.save(entry);
    }

    @Transactional
    public void cancelQueueEntry(Integer queueEntryId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);
        entry.setStatus("CANCELLED");
        queueEntryRepository.save(entry);
    }

    @Transactional
    public void unassignWorker(Integer queueEntryId) {
        QueueEntry entry = getQueueEntryById(queueEntryId);

        if (!"ASSIGNED".equals(entry.getStatus())) {
            throw new RuntimeException("Назначение можно снять только у записи со статусом 'ASSIGNED'");
        }

        // Удаляем назначение
        List<QueueAssignment> assignments = queueAssignmentRepository.findByQueueEntryId(queueEntryId);
        if (!assignments.isEmpty()) {
            queueAssignmentRepository.deleteAll(assignments);
        }

        entry.setAssignedWorker(null);
        entry.setStatus("PENDING");
        queueEntryRepository.save(entry);
    }

    public List<LocalTime> getFreeSlots(LocalDate date) {
        List<LocalTime> allSlots = List.of(
                LocalTime.of(9, 0), LocalTime.of(9, 30),
                LocalTime.of(10, 0), LocalTime.of(10, 30),
                LocalTime.of(11, 0), LocalTime.of(11, 30),
                LocalTime.of(12, 0), LocalTime.of(12, 30),
                LocalTime.of(13, 0), LocalTime.of(13, 30),
                LocalTime.of(14, 0), LocalTime.of(14, 30),
                LocalTime.of(15, 0), LocalTime.of(15, 30),
                LocalTime.of(16, 0), LocalTime.of(16, 30),
                LocalTime.of(17, 0), LocalTime.of(17, 30)
        );

        List<QueueEntry> busyEntries = queueEntryRepository.findByEntryDateOrderByQueueNumberAsc(date);
        List<LocalTime> busySlots = busyEntries.stream()
                .filter(e -> !e.getStatus().equals("CANCELLED") && !e.getStatus().equals("COMPLETED"))
                .map(QueueEntry::getSlotTime)
                .collect(Collectors.toList());

        return allSlots.stream()
                .filter(slot -> !busySlots.contains(slot))
                .collect(Collectors.toList());
    }
}