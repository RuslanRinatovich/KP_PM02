package com.carwash.service;

import com.carwash.entity.QueueEntry;
import com.carwash.repository.QueueEntryRepository;
import com.lowagie.text.*;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final QueueEntryRepository queueEntryRepository;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    // Вспомогательный метод для получения шрифта с поддержкой кириллицы
    private Font getRussianFont(float size, int style) {
        try {
            // Загружаем шрифт Arial из ресурсов (положите файл arial.ttf в src/main/resources/fonts/)
            BaseFont baseFont = BaseFont.createFont("/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            return new Font(baseFont, size, style);
        } catch (Exception e) {
            e.printStackTrace();
            // fallback – может не работать с кириллицей
            return FontFactory.getFont(FontFactory.HELVETICA, size, style);
        }
    }

    // ==================== EXCEL: Отчёт по записям ====================
    public byte[] generateQueueExcel(LocalDate startDate, LocalDate endDate) throws IOException {
        List<QueueEntry> entries = queueEntryRepository.findQueueEntriesForPeriod(startDate, endDate);

        try (org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Записи на мойку");
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            String[] columns = {"№", "Дата", "Время", "Клиент", "Госномер", "Тип авто", "Услуга", "Цена", "Статус"};
            for (int i = 0; i < columns.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(getHeaderStyle(workbook));
            }

            int rowNum = 1;
            int counter = 1;
            for (QueueEntry e : entries) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(counter++);
                row.createCell(1).setCellValue(e.getEntryDate().format(DATE_FORMATTER));
                row.createCell(2).setCellValue(e.getSlotTime().toString());
                row.createCell(3).setCellValue(e.getUser().getFullName());
                row.createCell(4).setCellValue(e.getLicensePlate());
                row.createCell(5).setCellValue(e.getCarType() != null ? e.getCarType() : "—");
                row.createCell(6).setCellValue(e.getService().getName());
                row.createCell(7).setCellValue(e.getService().getPrice().doubleValue());
                row.createCell(8).setCellValue(getStatusRu(e.getStatus()));
            }
            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }
            workbook.write(out);
            return out.toByteArray();
        }
    }

    // ==================== EXCEL: Финансовый отчёт ====================
    public byte[] generateFinancialExcel(int year, int month) throws IOException {
        LocalDate firstDay = LocalDate.of(year, month, 1);
        LocalDate lastDay = firstDay.withDayOfMonth(firstDay.lengthOfMonth());
        List<Object[]> dailyRevenue = queueEntryRepository.getDailyRevenue(firstDay, lastDay);

        try (org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Выручка за " + month + "." + year);
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Дата");
            headerRow.createCell(1).setCellValue("Выручка (₽)");
            headerRow.getCell(0).setCellStyle(getHeaderStyle(workbook));
            headerRow.getCell(1).setCellStyle(getHeaderStyle(workbook));

            int rowNum = 1;
            double total = 0;
            for (Object[] rowData : dailyRevenue) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(((LocalDate) rowData[0]).format(DATE_FORMATTER));
                double amount = ((Number) rowData[1]).doubleValue();
                row.createCell(1).setCellValue(amount);
                total += amount;
            }
            // Строка итого
            org.apache.poi.ss.usermodel.Row totalRow = sheet.createRow(rowNum);
            totalRow.createCell(0).setCellValue("ИТОГО:");
            totalRow.createCell(1).setCellValue(total);
            totalRow.getCell(0).setCellStyle(getBoldStyle(workbook));
            totalRow.getCell(1).setCellStyle(getBoldStyle(workbook));

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);
            workbook.write(out);
            return out.toByteArray();
        }
    }

    // ==================== PDF: Отчёт по записям ====================
    public byte[] generateQueuePdf(LocalDate startDate, LocalDate endDate) throws Exception {
        List<QueueEntry> entries = queueEntryRepository.findQueueEntriesForPeriod(startDate, endDate);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, out);
        document.open();

        Font titleFont = getRussianFont(16, Font.BOLD);
        Paragraph title = new Paragraph("Отчёт по записям\n", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph("Период: " + startDate.format(DATE_FORMATTER) + " – " + endDate.format(DATE_FORMATTER) + "\n\n"));

        PdfPTable table = new PdfPTable(9);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        String[] headers = {"№", "Дата", "Время", "Клиент", "Госномер", "Тип авто", "Услуга", "Цена", "Статус"};
        for (String h : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(h, getRussianFont(10, Font.BOLD)));
            cell.setBackgroundColor(new Color(211, 211, 211));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }

        int counter = 1;
        for (QueueEntry e : entries) {
            table.addCell(String.valueOf(counter++));
            table.addCell(e.getEntryDate().format(DATE_FORMATTER));
            table.addCell(e.getSlotTime().toString());
            table.addCell(e.getUser().getFullName());
            table.addCell(e.getLicensePlate());
            table.addCell(e.getCarType() != null ? e.getCarType() : "—");
            table.addCell(e.getService().getName());
            table.addCell(e.getService().getPrice().toString());
            table.addCell(getStatusRu(e.getStatus()));
        }
        document.add(table);
        document.close();
        return out.toByteArray();
    }

    // ==================== PDF: Загрузка по типам кузова ====================
    public byte[] generateUtilizationPdf(LocalDate startDate, LocalDate endDate) throws Exception {
        List<Object[]> utilization = queueEntryRepository.getCarTypeUtilization(startDate, endDate);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, out);
        document.open();

        Font titleFont = getRussianFont(16, Font.BOLD);
        Paragraph title = new Paragraph("Загрузка по типам кузова\n", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph("Период: " + startDate.format(DATE_FORMATTER) + " – " + endDate.format(DATE_FORMATTER) + "\n\n"));

        PdfPTable table = new PdfPTable(3);
        table.setWidthPercentage(100);
        String[] headers = {"Тип кузова", "Количество", "Доля (%)"};
        for (String h : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(h, getRussianFont(10, Font.BOLD)));
            cell.setBackgroundColor(new Color(211, 211, 211));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }

        long total = utilization.stream().mapToLong(u -> ((Number) u[1]).longValue()).sum();
        for (Object[] u : utilization) {
            String carType = (String) u[0];
            long count = ((Number) u[1]).longValue();
            int percent = total > 0 ? (int) Math.round((count * 100.0) / total) : 0;
            table.addCell(carType != null ? carType : "Не указан");
            table.addCell(String.valueOf(count));
            table.addCell(percent + "%");
        }
        document.add(table);
        document.close();
        return out.toByteArray();
    }

    // ==================== EXCEL: Статистика по услугам ====================
    public byte[] generateServiceStatsExcel(LocalDate startDate, LocalDate endDate) throws IOException {
        List<Object[]> stats = queueEntryRepository.getServiceStats(startDate, endDate);

        try (org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Статистика услуг");
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Услуга");
            headerRow.createCell(1).setCellValue("Количество");
            headerRow.createCell(2).setCellValue("Выручка (₽)");
            headerRow.getCell(0).setCellStyle(getHeaderStyle(workbook));
            headerRow.getCell(1).setCellStyle(getHeaderStyle(workbook));
            headerRow.getCell(2).setCellStyle(getHeaderStyle(workbook));

            int rowNum = 1;
            double totalRevenue = 0;
            long totalCount = 0;
            for (Object[] rowData : stats) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue((String) rowData[0]);
                long count = ((Number) rowData[1]).longValue();
                double revenue = ((Number) rowData[2]).doubleValue();
                row.createCell(1).setCellValue(count);
                row.createCell(2).setCellValue(revenue);
                totalCount += count;
                totalRevenue += revenue;
            }
            // Строка итого
            org.apache.poi.ss.usermodel.Row totalRow = sheet.createRow(rowNum);
            totalRow.createCell(0).setCellValue("ИТОГО:");
            totalRow.createCell(1).setCellValue(totalCount);
            totalRow.createCell(2).setCellValue(totalRevenue);
            totalRow.getCell(0).setCellStyle(getBoldStyle(workbook));
            totalRow.getCell(1).setCellStyle(getBoldStyle(workbook));
            totalRow.getCell(2).setCellStyle(getBoldStyle(workbook));

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);
            sheet.autoSizeColumn(2);
            workbook.write(out);
            return out.toByteArray();
        }
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private org.apache.poi.ss.usermodel.CellStyle getHeaderStyle(org.apache.poi.ss.usermodel.Workbook workbook) {
        org.apache.poi.ss.usermodel.CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(org.apache.poi.ss.usermodel.IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(org.apache.poi.ss.usermodel.FillPatternType.SOLID_FOREGROUND);
        return style;
    }

    private org.apache.poi.ss.usermodel.CellStyle getBoldStyle(org.apache.poi.ss.usermodel.Workbook workbook) {
        org.apache.poi.ss.usermodel.CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        return style;
    }

    private String getStatusRu(String status) {
        switch (status) {
            case "PENDING": return "Ожидает";
            case "ASSIGNED": return "Назначен";
            case "IN_PROGRESS": return "В процессе";
            case "COMPLETED": return "Завершён";
            case "CANCELLED": return "Отменён";
            default: return status;
        }
    }
}