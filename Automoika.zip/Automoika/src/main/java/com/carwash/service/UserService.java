package com.carwash.service;

import com.carwash.dto.UserDto;
import com.carwash.entity.User;
import com.carwash.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public List<UserDto> findAllUsers() {
        return userRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<UserDto> searchUsers(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAllUsers();
        }
        return userRepository.searchUsers(keyword.trim()).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public UserDto getUserById(Integer id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));
        return convertToDto(user);
    }

    @Transactional
    public void saveUser(UserDto dto) {
        if (dto.getId() == null) {
            // ===== СОЗДАНИЕ =====
            if (dto.getPassword() == null || dto.getPassword().isBlank()) {
                throw new RuntimeException("Пароль обязателен для нового пользователя");
            }
            if (userRepository.existsByUsername(dto.getUsername())) {
                throw new RuntimeException("Логин '" + dto.getUsername() + "' уже занят");
            }
            if (userRepository.existsByEmail(dto.getEmail())) {
                throw new RuntimeException("Email '" + dto.getEmail() + "' уже занят");
            }

            User user = new User();
            user.setUsername(dto.getUsername());
            user.setPassword(passwordEncoder.encode(dto.getPassword()));
            user.setFullName(dto.getFullName());
            user.setEmail(dto.getEmail());
            user.setPhone(dto.getPhone());
            user.setRole(dto.getRole());
            user.setWorker(dto.getRole().equals("OPERATOR") && dto.isWorker());
            user.setEnabled(dto.isEnabled());

            userRepository.save(user);
        } else {
            // ===== ОБНОВЛЕНИЕ =====
            User existing = userRepository.findById(dto.getId())
                    .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

            if (!existing.getUsername().equals(dto.getUsername()) &&
                    userRepository.existsByUsername(dto.getUsername())) {
                throw new RuntimeException("Логин '" + dto.getUsername() + "' уже занят");
            }
            if (!existing.getEmail().equals(dto.getEmail()) &&
                    userRepository.existsByEmail(dto.getEmail())) {
                throw new RuntimeException("Email '" + dto.getEmail() + "' уже занят");
            }

            existing.setUsername(dto.getUsername());
            existing.setFullName(dto.getFullName());
            existing.setEmail(dto.getEmail());
            existing.setPhone(dto.getPhone());
            existing.setRole(dto.getRole());
            existing.setWorker(dto.getRole().equals("OPERATOR") && dto.isWorker());
            existing.setEnabled(dto.isEnabled());

            if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
                existing.setPassword(passwordEncoder.encode(dto.getPassword()));
            }

            userRepository.saveAndFlush(existing);
        }
    }

    @Transactional
    public void deleteUser(Integer id) {
        try {
            userRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Невозможно удалить пользователя, так как он связан с другими записями");
        }
    }

    public List<UserDto> getAllWorkers() {
        return userRepository.findAllWorkers().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private UserDto convertToDto(User user) {
        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setFullName(user.getFullName());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setRole(user.getRole());
        dto.setEnabled(user.isEnabled());
        dto.setWorker(user.isWorker());
        return dto;
    }
}