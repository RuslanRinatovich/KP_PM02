package com.carwash.service;

import com.carwash.dto.WashServiceDto;
import com.carwash.entity.WashService;
import com.carwash.repository.WashServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class WashServiceService {

    private final WashServiceRepository washServiceRepository;

    public List<WashServiceDto> findAllServices() {
        return washServiceRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<WashServiceDto> searchServices(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAllServices();
        }
        return washServiceRepository.searchServices(keyword.trim()).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public WashServiceDto getServiceById(Integer id) {
        WashService service = washServiceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Услуга не найдена"));
        return convertToDto(service);
    }

    @Transactional
    public void saveService(WashServiceDto dto) {
        if (dto.getId() == null) {
            // ===== СОЗДАНИЕ =====
            if (washServiceRepository.existsByName(dto.getName())) {
                throw new RuntimeException("Услуга с названием '" + dto.getName() + "' уже существует");
            }
            WashService service = new WashService();
            copyToEntity(dto, service);
            washServiceRepository.save(service);
        } else {
            // ===== ОБНОВЛЕНИЕ =====
            WashService existing = washServiceRepository.findById(dto.getId())
                    .orElseThrow(() -> new RuntimeException("Услуга не найдена"));
            if (!existing.getName().equals(dto.getName()) &&
                    washServiceRepository.existsByName(dto.getName())) {
                throw new RuntimeException("Услуга с названием '" + dto.getName() + "' уже существует");
            }
            copyToEntity(dto, existing);
            washServiceRepository.saveAndFlush(existing);
        }
    }

    @Transactional
    public void deleteService(Integer id) {
        try {
            washServiceRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException("Невозможно удалить услугу, так как она используется в записях очереди");
        }
    }

    private void copyToEntity(WashServiceDto dto, WashService service) {
        service.setName(dto.getName());
        service.setDescription(dto.getDescription());
        service.setDurationMinutes(dto.getDurationMinutes());
        service.setPrice(dto.getPrice());
        service.setSortOrder(dto.getSortOrder() != null ? dto.getSortOrder() : 0);
        service.setActive(dto.isActive());
    }

    private WashServiceDto convertToDto(WashService service) {
        WashServiceDto dto = new WashServiceDto();
        dto.setId(service.getId());
        dto.setName(service.getName());
        dto.setDescription(service.getDescription());
        dto.setDurationMinutes(service.getDurationMinutes());
        dto.setPrice(service.getPrice());
        dto.setSortOrder(service.getSortOrder());
        dto.setActive(service.isActive());
        return dto;
    }
}