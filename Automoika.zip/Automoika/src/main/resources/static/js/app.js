// app.js - общие скрипты для приложения

// Обработка кликов по пунктам меню (динамическая загрузка)
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.menu-item[data-url]').forEach(item => {
        item.addEventListener('click', function(e) {
            const url = this.getAttribute('data-url');
            if (url) {
                loadContent(url);
                setActiveMenu(this);
            }
        });
    });
});

function loadContent(url) {
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.text())
    .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const newContent = doc.querySelector('.content-area');
        if (newContent) {
            document.querySelector('.content-area').innerHTML = newContent.innerHTML;
            const newTitle = doc.querySelector('.page-title span');
            if (newTitle) {
                document.querySelector('.page-title span').innerText = newTitle.innerText;
            }
            history.pushState({}, '', url);
        }
    })
    .catch(error => console.error('Error loading content:', error));
}

function setActiveMenu(activeItem) {
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });
    activeItem.classList.add('active');
}